# Pedro News
I'm writing a bi-weekly journal to keep Ed updated on my life.

_08/09/2016_

### TL; DR
